﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace ABCBANKUI
{
    public class ErrorHandler
    {

        public static string getErrormsg(string operation, Exception ex)
        {
            string errorMsg=string.Empty;

            if ((ex is SqlException))

            {
                
                if(ex.Message.Contains("Primary Key"))
                      return "Already exists";
                else if(ex.Message.Contains("Unique Key"))
                      return "Already exists";
                else
                {
                    if (operation == "Add")
                    {
                        return "Error in adding details";
                    }
                    if (operation == "Delete")
                    {
                        return "Error in deleting details";
                    }
                    else if (operation == "View")
                    {
                        return "Error in Viewing details";
                    }
                }
            }
            else if(ex is FormatException)
            {
                return "Error in Format";

            }


            return errorMsg;

        }


    }
}
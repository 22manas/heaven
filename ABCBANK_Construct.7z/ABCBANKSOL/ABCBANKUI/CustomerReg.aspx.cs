﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Types;
using ABABANKBLLFACTORY;
using ABCBANKBOFACTORY;
using ABCBANKBO;
using ABCBANKBLL;

namespace ABCBANKUI
{
    public partial class CustomerReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            ICustomerBO objCustomer = ABCBANKBOFACTORY.CustomerBOFactory.CreateCustomerBO()
            try
            {
            objCustomer.CustomerName = txtName.Text;
            objCustomer.DOB = DateTime.Parse(txtDOB.Text);
            objCustomer.BranchID = int.Parse(ddlBarnch.SelectedValue);
            ICustomerBLL objcustomerbll = new CustomerBLL();
            int ret = objcustomerbll.AddCustomer(objCustomer);

            }
            catch(Exception ex)
            {
               string msg= ErrorHandler.getErrormsg("Add", ex);
               Label1.Text = msg;

            }
           
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Types;
using ABCBANKBOFACTORY;
using ABCBANKDALFACTORY;

namespace ABCBANKBLL
{
    public class CustomerBLL:ICustomerBLL
    {
        public int AddCustomer(ICustomerBO obj)
        {
            int ret = 0;
            ICustomerDAL objcustDAL = ABCBANKDALFACTORY.CustomerDALFactory.CreateCustomerDAL();
            DateTime currday = DateTime.Now;
            try
            {
                int Days = currday.Year - obj.DOB.Year;


                if (Days > 60)
                {
                    obj.ISSeniorCustomer = true;

                }
                else
                {
                    obj.ISSeniorCustomer = false;

                }
           
                    ret = objcustDAL.AddCustomer(obj);
            }
            catch
            {
                throw;
            }

            return ret;

        }

        public int UpdateCustomer(ICustomerBO obj)
        {
            int ret = 0;
            ICustomerDAL objcustDAL = ABCBANKDALFACTORY.CustomerDALFactory.CreateCustomerDAL(); 
            ret = objcustDAL.updateCustomer(obj);
            return ret;

        }

        public int DeleteCustomet(ICustomerBO obj)
        {
            int ret = 0;
            ICustomerDAL objcustDAL = ABCBANKDALFACTORY.CustomerDALFactory.CreateCustomerDAL();
            ret = objcustDAL.DeleteCustomer(obj);
            return ret;

        }

        public DataTable ViewCustomers()
        {

            ICustomerDAL objcustDAL = ABCBANKDALFACTORY.CustomerDALFactory.CreateCustomerDAL();
            return objcustDAL.ViewCustomers();
            

        }

        public ICustomerBO ViewCustomer(int customerID)
        {

            ICustomerDAL objcustDAL = ABCBANKDALFACTORY.CustomerDALFactory.CreateCustomerDAL();
            return objcustDAL.ViewCustomer(customerID);


        }





    }
}

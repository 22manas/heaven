﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Types
{
    public interface ICustomerDAL
    {
         int AddCustomer(ICustomerBO objcust);
         int updateCustomer(ICustomerBO objcust);
         int DeleteCustomer(ICustomerBO objcust);
         DataTable ViewCustomers();
         ICustomerBO ViewCustomer(int customerID);
    }
}

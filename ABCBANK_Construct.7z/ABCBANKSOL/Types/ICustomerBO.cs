﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;

namespace Types
{
    public interface ICustomerBO
    {
         int CustomerID { get; set; }
         string CustomerName { get; set; }
        int BranchID { get; set; }
         DateTime DOB { get; set; }
       bool ISSeniorCustomer { get; set; }
       


    }
}

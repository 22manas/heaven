﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement118
{
    class Canidate:ICanidate
    {
        int canidatetId;
        string canidateName;
        string addres;
        int vacancyId;
        int experience;
        public int CanidateId
        {
            get
            {
                return canidatetId;
            }
            set
            {
                canidatetId  = value;
            }
        }
        public string CanidateName
        {
            get
            {
                return canidateName;
            }
            set
            {
                canidateName = value;
            }
        }
        public string Addres
        {
            get
            {
                return addres;
            }
            set
            {
                addres = value;
            }
        }
        public int VacancyId
        {
            get
            {
                return vacancyId;
            }
            set
            {
                vacancyId = value;
            }
        }
        public int Experience
        {
            get
            {
                return experience;
            }
            set
            {
                experience = value;
            }
        }
        
     public Canidate()
        {

        }
        public Canidate(int cid,string cnmae,string add,string b)
     {

     }
  

        
    }
}

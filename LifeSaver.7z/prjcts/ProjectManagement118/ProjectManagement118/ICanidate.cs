﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement118
{
    interface ICanidate
    {
        int CanidateId{get; set;}
        string CanidateName {get;set;}
        string Addres{get;set;}
         int VacancyId{get;set;}
        int  Experience{get;set;}
    } 
}
 
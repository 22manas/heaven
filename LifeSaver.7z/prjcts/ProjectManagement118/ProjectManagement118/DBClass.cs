﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ProjectManagement118
{
    class DBClass
    {
        static SqlConnection cn;
        static SqlCommand cmd;

        static SqlConnection GetConnection()
        {
             string conStr = "Data Source=inchnilpdb02\\mssqlServer1;Initial Catalog=CHN16_MMS98_Test;User Id = mms98user;Password =mms98user";
             try
             {
                 if (!string.IsNullOrEmpty(conStr))
                 {
                     return new SqlConnection(conStr);
                 }
                 else
                 {
                     Console.WriteLine("connection1 is not me");
                     return null;
                 }
             }
             catch
             {
                 Console.WriteLine("connection is not maintained.");
                 return null;
             }
        
        }
        public static int AddCanidate(Canidate objCanidate)
        {
            cn = GetConnection();
            try
            {

                if (cn.State == System.Data.ConnectionState.Closed)
                {
                    cn.Open();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            cmd = new SqlCommand("Add_Canidate1", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@CanidateName", objCanidate.CanidateName));
            cmd.Parameters.Add(new SqlParameter("@Addres", objCanidate.Addres));
            cmd.Parameters.Add(new SqlParameter("@VacancyId", objCanidate.VacancyId));
            cmd.Parameters.Add(new SqlParameter("@Experience", objCanidate.Experience));
            //SqlParameter stdNoParam = cmd.Parameters.Add("@CanidateId", SqlDbType.Int);
            //stdNoParam.Direction = ParameterDirection.Output;
            int i=0;
            try
            {
                i= cmd.ExecuteNonQuery();
                cn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                cn.Close();
            }

            return i;


        }

        public static List<Canidate> ViewCanidate()
        {
            List<Canidate> lstCanidate = new List<Canidate>();
            cn = GetConnection();
            if(cn.State==ConnectionState.Closed)
            {
                cn.Open();
            }
            Console.WriteLine("Enter the candidate id");
            int id = Convert.ToInt32(Console.ReadLine());
            cmd = new SqlCommand("View_Canidate2", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@CanidateId", id));
           


            SqlDataReader CanidateReader = cmd.ExecuteReader();
                
                while(CanidateReader.Read())
            {
                Canidate objCanidate = new Canidate();
                objCanidate.CanidateId = Convert.ToInt32(CanidateReader["CanidateId"].ToString());
                objCanidate.CanidateName = CanidateReader["CanidateName"].ToString();
                objCanidate.Addres = CanidateReader["Addres"].ToString();
                objCanidate.VacancyId = Convert.ToInt32(CanidateReader["VacancyId"].ToString());
                objCanidate.Experience = Convert.ToInt32(CanidateReader["Experience"].ToString());
                lstCanidate.Add(objCanidate);
            }
            return lstCanidate;
        }
    }
}

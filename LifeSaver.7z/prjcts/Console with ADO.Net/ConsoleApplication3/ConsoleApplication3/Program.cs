﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            menu();
            int option;
            Console.WriteLine("Please enter option");
            option = int.Parse(Console.ReadLine());
            while(option !=5)
            {
                switch(option)
                {

                    case 1: AddStudent();
                        break;

                    case 2: ViewStudents();
                        break;

                    case 3: ModifyStudent();
                        break;

                    case 4: DeleteStudent();
                        break;
                    case 5 : break;
                }

                menu();
                Console.WriteLine("Please enter option");
                option = int.Parse(Console.ReadLine());



                }

               Console.ReadLine();


        }


        static void menu()
        {
            Console.WriteLine("Menu");
            Console.WriteLine("1.Add Student");
            Console.WriteLine("2.View Students");
            Console.WriteLine("3.Modify Student");
            Console.WriteLine("4.Delete Student");

            

        }

        static void AddStudent()
        {
            string name;
            int marks;
            Console.WriteLine("Enter name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Marks");
            marks = int.Parse(Console.ReadLine());
            Student objstudent = new Student();
            objstudent.StudentName = name;
            objstudent.Marks = marks;
            int result = DBClass.AddStudent(objstudent);
            if (result == 1)
            {

                Console.WriteLine("Student added.ID:" + result);
            }
        }


         static void DeleteStudent()
        {
           
            int id;
           
            Console.WriteLine("Enter Student ID");
            id = int.Parse(Console.ReadLine());
            
            bool result=DBClass.RemoveStudent(id);
            if(result==true)
            {

                Console.WriteLine("Student Deleted.");
            }
             
        }

         static void ViewStudents()
         {

             List<Student> lststudent = new List<Student>();
             lststudent = DBClass.ViewStudents();
             Console.WriteLine("Student Details");

             foreach (Student objstudent in lststudent)
             {
                 Console.WriteLine("Student ID:");
                 Console.WriteLine(objstudent.Studentid);
                 Console.WriteLine("Student Name:");
                 Console.WriteLine(objstudent.StudentName);
                 Console.WriteLine("Student Marks:");
                 Console.WriteLine(objstudent.Marks);
                 Console.WriteLine("Student Grade");
                 objstudent.displayGrade();



             }
         }

        

         static void ModifyStudent()
         {
             int id;

             Console.WriteLine("Enter Student ID");
             id = int.Parse(Console.ReadLine());

             Student objStudent = DBClass.SearchStudent(id);

             Console.WriteLine("Student Details");
             Console.WriteLine(objStudent.StudentName);
             Console.WriteLine(objStudent.Marks);


             Console.WriteLine("Enter 1 to modify name and 2 to modify marks");
             int opt = int.Parse(Console.ReadLine());
             if(opt==1)
             {
                 Console.WriteLine("Enter name");
                 objStudent.StudentName = Console.ReadLine();


             }
             else
             {
                 Console.WriteLine("Enter name");
                 objStudent.StudentName = Console.ReadLine();


             }

             bool result = DBClass.ModifyStudent(objStudent);
             if (result == true)
             {
                 Console.WriteLine("Student details updated");

                 objStudent = DBClass.SearchStudent(id);
                 Console.WriteLine("Updated Details");
                 Console.WriteLine(objStudent.StudentName);
                 Console.WriteLine(objStudent.Marks);

             }

             
         }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    interface IStudent
    {
        int Studentid { get; set; }
        string StudentName { get; set; }
        int Marks { get;set;}
        void displayGrade();



    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplyManagementSystem
{
    class DBClass
    {
        static SqlConnection cn;
        static SqlCommand cmd;

        static SqlConnection GetConnection()
        {
            string conStr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN16_MMS98_TEST;User ID=mms98user;Password=mms98user";
            try
            {
                if (!string.IsNullOrEmpty(conStr))
                {
                    return new SqlConnection(conStr);
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
        }
        
        public static int insert(Supplier sobj)
        {
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }
            cmd = new SqlCommand("sp_insert", cn);
            cmd.CommandType = CommandType.StoredProcedure;
             
            
         //   cmd.Parameters.Add(new SqlParameter("@sid", sobj.SupplierID));
            cmd.Parameters.Add(new SqlParameter("@SupplierName", sobj.SupplierName));
              cmd.Parameters.Add(new SqlParameter("@Address", sobj.Addr));
             cmd.Parameters.Add(new SqlParameter("@ProductID", sobj.ProductID));
             int i = cmd.ExecuteNonQuery();
             cn.Close();
             
            if (i > 0)
             {
                 Console.WriteLine("{0} : "+i+"rows inserted");
             }
             return 0;
        }


        public static int display(int id)
        {
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }
            cmd = new SqlCommand("d_supplier", cn);
            cmd.CommandType = CommandType.StoredProcedure;
          

            cmd.Parameters.Add(new SqlParameter("@SupplierID", id)); 
            Supplier sup =new Supplier();
            SqlDataReader stdReader = cmd.ExecuteReader();
            if (stdReader.Read())
            {
    
                //sup.SupplierID = id;
                sup.SupplierID = Convert.ToInt16(stdReader[0].ToString());
                sup.SupplierName = stdReader[1].ToString();
                sup.Addr = stdReader[2].ToString();
                sup.ProductID = Convert.ToInt16(stdReader[3].ToString());
                Console.WriteLine(sup.SupplierID + " " + sup.SupplierName + " " + sup.Addr + " " + sup.ProductID);

            }
            return 0;
        }


        public static bool delete(int id)
        {
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }
            cmd = new SqlCommand("del_supplier", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            

            cmd.Parameters.Add(new SqlParameter("@SupplierID", id));

            Supplier sup = new Supplier();
            int result = cmd.ExecuteNonQuery();
            cn.Close();
            if (result > 0)
            {
                return true;
            }
            return false;
        }

        public static void update(Supplier obj)
        {
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }

            cmd = new SqlCommand("u_supplier", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@SupplierID", obj.SupplierID));
            cmd.Parameters.Add(new SqlParameter("@SupplierName", obj.SupplierName));
            cmd.Parameters.Add(new SqlParameter("@Address", obj.Addr));
            cmd.Parameters.Add(new SqlParameter("@ProductID", obj.ProductID));
            int result = cmd.ExecuteNonQuery();
            cn.Close();
           
        }

        public static Supplier search(int id)
        {
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }

            cmd = new SqlCommand("d_supplier", cn);
            cmd.CommandType = CommandType.StoredProcedure;

            Supplier sup = new Supplier();
            cmd.Parameters.Add(new SqlParameter("@SupplierID", id));
            SqlDataReader stdReader = cmd.ExecuteReader();
            
            if (stdReader.Read())
            {
                Console.WriteLine("Found !!");

            }
            return sup;
        }
    }
}

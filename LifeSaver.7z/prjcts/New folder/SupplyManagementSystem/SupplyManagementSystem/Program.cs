﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplyManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice;
            do
            {

                Console.WriteLine("*********menu*********");
                Console.WriteLine("1.add");
                Console.WriteLine("2.update");
                Console.WriteLine("3.display");
                Console.WriteLine("4.delete");
               Console.WriteLine("5.exit");
               Console.WriteLine("enter ur choice");
               choice = int.Parse(Console.ReadLine());

                switch(choice)
                {
                    case 1:
                       insert();
                        break;
                    case 2:
                         Console.WriteLine("enter supplierId");
            int id = int.Parse(Console.ReadLine());
                        search(id);
                        update(id);
                        break;
                    case 3:
                        display();
                        break;
                    case 4:
                        delete();
                        break;
                    case 5:
                        break;
                }
            } while (choice != 5);
        }
       static void insert()
        {
            Supplier sobj = new Supplier();

                        // Console.WriteLine("enter supplierId");
                       // sobj.SupplierID= int.Parse(Console.ReadLine());
                        Console.WriteLine("enter suppliername");
                        sobj.SupplierName= Console.ReadLine();
                        Console.WriteLine("enter address");
                        sobj.Addr = Console.ReadLine();
                        Console.WriteLine("enter productId");
                        sobj.ProductID= int.Parse(Console.ReadLine());
                        
           int result = DBClass.insert(sobj);
                        if (result == 1)
                        {

                            Console.WriteLine("Row inserted" + result);
                        }

        }
        static void update(int id)
        {
        
            Supplier obj = new Supplier();
            obj.SupplierID=id;
            Console.WriteLine("Enter name");
            obj.SupplierName = Console.ReadLine();
            Console.WriteLine("Enter address");
                    obj.Addr = Console.ReadLine();
            Console.WriteLine("Enter product id");
                    obj.ProductID = int.Parse(Console.ReadLine());

            DBClass.update(obj);

           /* if (obj.SupplierID == id)
            {
                Console.WriteLine("Supplier Details");
                Console.WriteLine(obj.SupplierName);
                Console.WriteLine(obj.Addr);
                Console.WriteLine(obj.ProductID);


                Console.WriteLine("Enter 1 to modify name \n 2 to modify addr \n 3 to modify product id");
                int opt = int.Parse(Console.ReadLine());
                if (opt == 1)
                {
                    Console.WriteLine("Enter name");
                    obj.SupplierName = Console.ReadLine();


                }
                if (opt == 2)
                {
                    Console.WriteLine("Enter address");
                    obj.Addr = Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Enter product id");
                    obj.ProductID = int.Parse(Console.ReadLine());
                }*/
               // DBClass.update(obj);
            

        }
        static void display()
        {
            Supplier sobj = new Supplier();

            Console.WriteLine("enter supplierId");
            int id = int.Parse(Console.ReadLine());
            int result = DBClass.display(id);


        }
        static void delete()
        {
            int id;

            Console.WriteLine("Enter Supplier ID");
            id = int.Parse(Console.ReadLine());

            bool result = DBClass.delete(id);
            if (result == true)
            {

                Console.WriteLine("Supplier Deleted.");
            }
             
        }
        static void search(int id)
        {

            DBClass.search(id);
        }
    }
}

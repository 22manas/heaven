﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplyManagementSystem
{
    class Supplier : ISupplier
    {
        private int supplierId=0;
        private string supplierName=string.Empty;
        private string addr =string.Empty;
        private int productId=0;

        public int SupplierID
        {
            get { return supplierId; }
            set { supplierId = value; }
        }
        public string SupplierName
        {
            get { return supplierName; }
            set { supplierName = value; }
        }
        public string Addr
        {
            get { return addr; }
            set { addr = value; }
        }
        public int ProductID
        {
            get { return productId; }
            set { productId = value; }
        }

        public Supplier(int sid, string sname, string addr, int pid)
        {
            SupplierID = sid;
            SupplierName = sname;
            Addr = addr;
            ProductID = pid;
        }
        public Supplier()
        { }
    }
}

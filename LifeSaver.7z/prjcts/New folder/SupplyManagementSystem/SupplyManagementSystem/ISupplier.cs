﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplyManagementSystem
{
    interface ISupplier
    {
        int SupplierID { get; set; }
        string SupplierName { get; set; }
        string Addr { get; set; }
        int ProductID { get; set; }
       
    }

}
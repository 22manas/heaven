USE [CHN16_MMS98_TEST]
GO

/****** Object:  StoredProcedure [dbo].[sp_insert]    Script Date: 9/8/2016 1:22:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER procedure [dbo].[sp_insert](
@SupplierName varchar(50),
@Address varchar(100),
@ProductID int)
as
begin
insert tbl_Supplier(SupplierName,Address,ProductID) values(@SupplierName,@Address,@ProductID)
end
GO



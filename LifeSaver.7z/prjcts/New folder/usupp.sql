USE [CHN16_MMS98_TEST]
GO

/****** Object:  StoredProcedure [dbo].[u_supplier]    Script Date: 9/8/2016 1:23:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER proc [dbo].[u_supplier]
(@SupplierID int,
@SupplierName varchar(50),
@Address varchar(100),
@ProductID int)
as 
begin
update tbl_Supplier set SupplierName=@SupplierName, Address=@Address, ProductID=@ProductID where SupplierID=@SupplierID
end
GO



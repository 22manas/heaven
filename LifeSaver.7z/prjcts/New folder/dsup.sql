USE [CHN16_MMS98_TEST]
GO

/****** Object:  StoredProcedure [dbo].[d_supplier]    Script Date: 9/8/2016 1:22:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER proc [dbo].[d_supplier]
(@SupplierID int)
as
begin
select * from tbl_Supplier where SupplierID=@SupplierID
end
GO



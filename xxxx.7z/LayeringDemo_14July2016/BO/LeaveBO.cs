﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class LeaveBO
    {
        public long LeaveID { get; set; }
        public long EmployeeID { get; set; }
        public string LeaveType { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public long ContactNo { get; set; }
        public string Comments { get; set; }
        public string LeaveStatus { get; set; }
    }
}

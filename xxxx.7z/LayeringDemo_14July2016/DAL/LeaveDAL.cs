﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class LeaveDAL
    {
        //Applying Leave
        public long ApplyLeave(LeaveBO lbo)
        {
            //1. Create the Connection object
            SqlConnection cn = new SqlConnection("data source=172.25.192.80;user id=pj01HMS001;password=tcshyd;initial catalog=DB01HMS001");
            //2. Create the Command Object
            SqlCommand cmd = new SqlCommand("usp_ApplyLeave_LayeringDemo", cn);
            cmd.CommandType = CommandType.StoredProcedure;

            //Pass the required no. of parameters for executing
            cmd.Parameters.AddWithValue("@EmployeeID", lbo.EmployeeID);
            cmd.Parameters.AddWithValue("@LeaveType", lbo.LeaveType);
            cmd.Parameters.AddWithValue("@FromDate", lbo.StartDate);
            cmd.Parameters.AddWithValue("@ToDate", lbo.EndDate);
            cmd.Parameters.AddWithValue("@ContactNo", lbo.ContactNo);
            cmd.Parameters.AddWithValue("@Comments", lbo.Comments);
            cmd.Parameters.AddWithValue("@LeaveStatus", lbo.LeaveStatus);
            SqlParameter idParam = cmd.Parameters.Add("@LeaveID", SqlDbType.Int);
            idParam.Direction = ParameterDirection.Output;


            //3. Open the Connection
            if (cn.State == ConnectionState.Closed)
                cn.Open();

            //4. Execute the Command object
            cmd.ExecuteNonQuery();

            return Convert.ToInt32(idParam.Value);
        }

        //View Leaves
        public DataTable ViewLeaves()
        {
            //1. Create the Connection object
            SqlConnection cn = new SqlConnection("data source=172.25.192.80;user id=pj01HMS001;password=tcshyd;initial catalog=DB01HMS001");
            //2. Create the DataAdapter Object
            SqlDataAdapter da = new SqlDataAdapter("usp_ViewLeaves_LayeringDemo", cn);
            //3.Create the dataset
            DataSet ds = new DataSet();
            da.Fill(ds, "Leaves");
            return ds.Tables["Leaves"];
            //Or
            //return ds.Tables[0];
        }

        //Getting the Employee IDs
         public List<long> GetEmployeeIDs()
        {
            //1. Create the Connection object
            SqlConnection cn = new SqlConnection("data source=172.25.192.80;user id=pj01HMS001;password=tcshyd;initial catalog=DB01HMS001");
            //2. Create the Command Object
            SqlCommand cmd = new SqlCommand("usp_GetEmployeeIDs_LayeringDemo", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            //3. Open the Connection
            if (cn.State == ConnectionState.Closed)
                cn.Open();

            //4. Execute the Command object
            SqlDataReader reader = cmd.ExecuteReader();

            //Read the values from datareader
            List<long> EmployeeIDsList = new List<long>();
            while (reader.Read())
            {
                EmployeeIDsList.Add(Convert.ToInt64(reader[0]));
            }
            return EmployeeIDsList;
        }
    
    }
}

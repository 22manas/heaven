﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DAL;
using System.Data;

namespace BLL
{
    public class LeaveBLL
    {
        LeaveDAL dalobj = new LeaveDAL();
        public long RequestLeave(LeaveBO lbo)
        {
           return dalobj.ApplyLeave(lbo);
        }

        public DataTable ViewLeaves()
        {
            return dalobj.ViewLeaves();
        }
        public List<long> GetEmployeeIDs()
        {
            return dalobj.GetEmployeeIDs();
        }
    }
}

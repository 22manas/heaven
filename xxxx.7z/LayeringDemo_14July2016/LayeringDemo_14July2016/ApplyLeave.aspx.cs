﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;

namespace LayeringDemo_14July2016
{
    public partial class ApplyLeave : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if(Page.IsPostBack==false) 
            if (!IsPostBack)
            {
                LeaveBLL lbll = new LeaveBLL();                
                ddlEmpIDs.DataSource=lbll.GetEmployeeIDs();
                ddlEmpIDs.DataBind();
                ddlEmpIDs.Items.Insert(0, "Select");
            }
            RangeValidator1.MinimumValue = DateTime.Now.ToShortDateString();
            RangeValidator1.MaximumValue = DateTime.Now.AddMonths(3).ToShortDateString();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                LeaveBO lbo = new LeaveBO();
                lbo.EmployeeID = Convert.ToInt64(ddlEmpIDs.SelectedValue);
                lbo.LeaveType = ddlLvType.SelectedValue;
                lbo.StartDate = Convert.ToDateTime(txtFromDate.Text);
                lbo.EndDate = Convert.ToDateTime(txtToDate.Text);
                lbo.ContactNo = Convert.ToInt64(txtPhNo.Text);
                lbo.Comments = txtComments.Text;
                lbo.LeaveStatus = "Pending";
                LeaveBLL lbll = new LeaveBLL();
                lbo.LeaveID=lbll.RequestLeave(lbo);
                if (lbo.LeaveID > 0)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "SuccessfulMesg", "alert('Leave applied successfully with the ID:" + lbo.LeaveID + "');", true);
                }
                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "FailureMesg", "alert('Invalid Details');", true);
                }
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            ddlEmpIDs.SelectedIndex = ddlLvType.SelectedIndex = 0;
            txtFromDate.Text = txtToDate.Text = txtComments.Text = txtPhNo.Text = "";
            ddlEmpIDs.Focus();
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (!Calendar1.Visible)
                Calendar1.Visible = true;
            else
                Calendar1.Visible = false;
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (!Calendar2.Visible)
                Calendar2.Visible = true;
            else
                Calendar2.Visible = false;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtFromDate.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            txtToDate.Text = Calendar2.SelectedDate.ToShortDateString();
            Calendar2.Visible = false;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;

namespace LayeringDemo_14July2016
{
    public partial class ViewLeaves : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LeaveBLL bllobj = new LeaveBLL();
            GridView1.DataSource = bllobj.ViewLeaves();
            GridView1.DataBind();
        }
    }
}
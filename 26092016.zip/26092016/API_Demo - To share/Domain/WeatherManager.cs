﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using RestSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System.Net;


namespace Domain
{
   public class WeatherManager
    {
        public RootObject getDetails(string location)
        {
            RestClient rc = new RestClient("https://apphonics.tcs.com/token");
            rc.Proxy = System.Net.HttpWebRequest.GetSystemWebProxy(); //reqd if you are behind proxy
            rc.Proxy.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["UserName"], ConfigurationManager.AppSettings["Password"], "India");

            var request = new RestRequest(Method.POST);

            request.AddHeader("Authorization", "Basic UmFfZWwyZHZ4cnAweTBpX0NBUmNEMDNiWHA0YTo1aHQxUGZTSUE0WXN0SllKZmRnVzVrTHJMNW9h, Content-Type: application/x-www-form-urlencoded");
            request.AddParameter("grant_type", "client_credentials");
            var resp = rc.Execute(request);
            if (resp.ResponseStatus == ResponseStatus.Completed && resp.StatusCode == System.Net.HttpStatusCode.OK)
            {
                ApphonicsToken T = JsonConvert.DeserializeObject<ApphonicsToken>(resp.Content);



                rc.BaseUrl = new Uri("https://apphonics.tcs.com/public/openweathermap/v1.0/weather");
                var req = new RestRequest(Method.GET);
                req.AddHeader("Authorization", "Bearer " + T.access_token);
                Console.WriteLine("Please enter the location");
                req.AddParameter("q", location);
                req.AddParameter("APPID", "538d0f66ff5e1dcb3c8963e5a2ee944b");

                var res = rc.Execute(req);
                if (res.ResponseStatus == ResponseStatus.Completed)
                {
                    var rootObj = JsonConvert.DeserializeObject<RootObject>(res.Content);

                    return rootObj;
               
                }
               
            }
            return null;  
        }
     
    }
}

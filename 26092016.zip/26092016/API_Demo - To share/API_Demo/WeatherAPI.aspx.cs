﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Domain;
using RestSharp;


namespace API_Demo
{
    public partial class WeatherAPI : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            tblShow.Visible = true;
            WeatherManager weather = new WeatherManager();
            RootObject root=weather.getDetails(txtLocation.Text);
            if(root!=null)
            {
                

                lblYourLocation.Text = "Location: " + root.name;
                lblCountry.Text = "Country: "+ root.sys.country;
                foreach (Weather w in root.weather)
                {
                   
                  
                       System.DateTime dateTime = new System.DateTime(1970, 1, 1, 0, 0, 0, 0);
                      dateTime = dateTime.AddSeconds(root.sys.sunrise);
                      lblSunrise.Text = "Sunrise: "+ dateTime.ToLocalTime();
                  
                       dateTime = new System.DateTime(1970, 1, 1, 0, 0, 0, 0);

                        dateTime = dateTime.AddSeconds(root.sys.sunset);

                        lblSunset.Text = "Sunset: "+ dateTime.ToLocalTime();
                    lblWeather.Text = "Weather: "+ w.description;
                    
                    
                    
                    img.ImageUrl = "http://openweathermap.org/img/w/"+w.icon+".png";
                 
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement118
{
    class Program
    {
        static void Main(string[] args)
        {
            int userinput;
            Console.WriteLine("***********MENU************");
            Console.WriteLine("1.AddCanidate");
            Console.WriteLine("2.ViewCanidate");
            Console.WriteLine("3.UpdateCanidate");
            Console.WriteLine("4.Exit");
            Console.WriteLine("Please choose any of the options");
            userinput = int.Parse(Console.ReadLine());
            while(userinput<4)
            {
                switch(userinput)
                {
                    case 1:
                        AddCanidate();
                        break;
                    case 2:
                        ViewCanidate();
                        break;
                    case 3:
                        //UpdateCanidate();
                        break;
                    case 4:
                        break;
                }
                Console.WriteLine("***********MENU************");
                Console.WriteLine("1.AddCanidate");
                Console.WriteLine("2.ViewCanidate");
                Console.WriteLine("3.UpdateCanidate");
                Console.WriteLine("4.Exit");
                Console.WriteLine("Please choose any of the options");
                userinput = int.Parse(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine();
            }
           
           
        }
        public static void AddCanidate()
        {
            
            string canidatename;
            string addres;
            int vacancyid;
            int experience;

            Console.WriteLine("Enter the Name of the Employeee:");
            canidatename = Console.ReadLine();
            Console.WriteLine("Enter the Address of the Employeee:");
            addres = Console.ReadLine();
            Console.WriteLine("Enter the vacancy ID");
            vacancyid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the years of experience of the Employeee:");
            experience = int.Parse(Console.ReadLine());

            Canidate objCanidate = new Canidate();
            objCanidate.CanidateName = canidatename;
            objCanidate.Addres = addres;
            objCanidate.VacancyId = vacancyid;
            objCanidate.Experience = experience;

            int result = DBClass.AddCanidate(objCanidate);
            if(result==1)
            {
                Console.WriteLine("Canidatre added");
            }
            else
            {
                Console.WriteLine("entryfailed");
            }


        }
        public static void ViewCanidate()
        {
            List<Canidate> lstCanidate = new List<Canidate>();
            lstCanidate = DBClass.ViewCanidate();
            Console.WriteLine("---------------STUDENT DETAILS---------------");
            foreach(Canidate objCanidate in lstCanidate)
            {
                Console.WriteLine("CanidateID:->");
                Console.WriteLine(objCanidate.CanidateId);
                Console.WriteLine("CanidatName:->");
                Console.WriteLine(objCanidate.CanidateName);
                Console.WriteLine("Address:->");
                Console.WriteLine(objCanidate.Addres);
                Console.WriteLine("VacancyId:->");
                Console.WriteLine(objCanidate.VacancyId);
                Console.WriteLine("Experience:->");
                Console.WriteLine(objCanidate.Experience);
            }

        }
        //public static void UpdateCanidate()
        //{
            
        //}
    }

}
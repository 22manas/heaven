﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    public interface ILoginBO
    {

        string Userid { get; set; }
        string Role { get; set; }
        string Password { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    public interface IStudentBO
    {
         string ID { get; set; }
         string Password { get; set; }
         string Status { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using studentbo;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Types;

namespace stdenentdal
{
    public class stddal:IStudentDAL
    {

        public int AddStudent(IStudentBO objstud)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;

            try
            {

                string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into studentlayer(id,password) values(@id,@password)";
                cmd.Parameters.AddWithValue("@id", objstud.ID);
                cmd.Parameters.AddWithValue("@password", objstud.Password);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                ret = cmd.ExecuteNonQuery();
                conn.Close();

            }
            catch (SqlException sqlex)
            {


                if (sqlex.Message.Contains("PRIMARY KEY"))
                {
                    ret= -2;
                }
                else
                {
                    ret= -1;
                }

            }
            catch (Exception e)
            {
                ret= -1;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }

            }
            return ret;

        }


        public int updateStudent(IStudentBO objstud)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;

            try
            {

                string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update studentlayer set status=@status where id=@id";
                cmd.Parameters.AddWithValue("@id", objstud.ID);
                cmd.Parameters.AddWithValue("@status", objstud.Status);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                ret = cmd.ExecuteNonQuery();
                conn.Close();

            }
            catch (SqlException sqlex)
            {


                if (sqlex.Message.Contains("PRIMARY KEY"))
                {
                    ret = -2;
                }
                else
                {
                    ret = -1;
                }

            }
            catch (Exception e)
            {
                ret = -1;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }

            }
            return ret;

        }



           public void DeleteStudent(string studeid)
        {
            //Code for Delete

        }

           public DataTable ViewStudent()
           {
               DataTable dt = new DataTable();
               SqlConnection conn = new SqlConnection();
               
               try
               {
                   SqlDataAdapter da = new SqlDataAdapter();

                   string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                   conn.ConnectionString = str;
                   conn.Open();
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandText = "Select * from studentlayer";
                   cmd.CommandType = CommandType.Text;
                   cmd.Connection = conn;
                   da.SelectCommand = cmd;
                   da.Fill(dt);
                   conn.Close();
                   return dt;
               }
               catch (Exception ex)
               {
                   return null;
               }
               finally
               {
                   if (conn.State == ConnectionState.Open)
                   {
                       conn.Close();
                   }
               }

           }


           public List<IStudentBO> ViewStudentList()
           {
               DataTable dt = new DataTable();
               SqlConnection conn = new SqlConnection();
               List<IStudentBO> lststudent=new List<IStudentBO>();
               try
               {
                   SqlDataAdapter da = new SqlDataAdapter();

                   string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                   conn.ConnectionString = str;
                   conn.Open();
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandText = "Select * from studentlayer";
                   cmd.CommandType = CommandType.Text;
                   cmd.Connection = conn;
                   da.SelectCommand = cmd;
                   da.Fill(dt);
                   conn.Close();

                   foreach(DataRow dr in dt.Rows)
                   {
                       IStudentBO objbo = new studbo();
                       objbo.ID = dr["id"].ToString();
                       objbo.Password = dr["password"].ToString();
                       objbo.Status = dr["active"].ToString();
                       lststudent.Add(objbo);


                   }

                   
                
               }
               catch (Exception ex)
               {
                   return null;
               }
               finally
               {
                   if (conn.State == ConnectionState.Open)
                   {
                       conn.Close();
                   }
               }

               return lststudent;

           }

           public string LoginStudent(ILoginBO objbo)
           {
               DataTable dt = new DataTable();
               SqlConnection conn = new SqlConnection();

               try
               {
                   SqlDataAdapter da = new SqlDataAdapter();

                   string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                   conn.ConnectionString = str;
                   conn.Open();
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandText = "Select active from studentlayer where id=@userid and password=@password";
                   cmd.CommandType = CommandType.Text;
                   cmd.Parameters.AddWithValue("@userid", objbo.Userid);
                   cmd.Parameters.AddWithValue("@password",objbo.Password);
                   cmd.Connection = conn;
                   da.SelectCommand = cmd;
                   da.Fill(dt);
                   conn.Close();
                   if (dt.Rows.Count == 0)
                   {
                       return string.Empty;
                   }
                   else
                   {
                       return dt.Rows[0]["active"].ToString();
                   }
                   
                   
               }
               catch (Exception ex)
               {
                   return null;
               }
               finally
               {
                   if (conn.State == ConnectionState.Open)
                   {
                       conn.Close();
                   }
               }

           }


    }
}

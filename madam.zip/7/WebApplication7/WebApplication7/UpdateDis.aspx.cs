﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication7
{
    public partial class Update : System.Web.UI.Page
    {
        DataSet ds;
        SqlDataAdapter da;
        SqlConnection con;
        SqlCommandBuilder bldr;
        DataRow dr;
        SqlCommand cmd;
             
       

        protected void Page_Load(object sender, EventArgs e)
        {

            populateSource();
            ddlDestination.Items.Insert(0, "Select");

               string conStr = System.Configuration.ConfigurationManager.ConnectionStrings["conn"].ConnectionString;

            
                con = new SqlConnection();
                con.ConnectionString = conStr;

                cmd = new SqlCommand("sp_Viewbus", con);
                cmd.CommandType = CommandType.StoredProcedure;


                da = new SqlDataAdapter();
                da.SelectCommand = cmd;

                //  da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                ds = new DataSet();
                da.Fill(ds, "Bus");



                DataTable dt = ds.Tables["Bus"];
                DataColumn[] keys = new DataColumn[1];
                keys[0] = dt.Columns["busid"];
                dt.PrimaryKey = keys;

                bldr = new SqlCommandBuilder(da);
           
            
                
                  
                
           

        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
             dr = ds.Tables[0].Rows.Find(txtBusID.Text);
             ddlSource.Text = dr["source"].ToString();
            populateDestination();
            ddlDestination.Text = dr["destination"].ToString();
            txtPrice.Text = dr["price"].ToString();

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            dr = ds.Tables[0].Rows.Find(txtBusID.Text);
            dr["destination"] = ddlDestination.Text;
            dr["source"]=ddlSource.Text;
            dr["price"] = int.Parse(txtPrice.Text);
           
            da.Update(ds, "Bus");
            Response.Write("Updated sucessfully");
                    
        }

        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            grdBus.DataSource = ds;
            grdBus.DataBind();
           
        }

        private void populateDestination()
        {
            ddlDestination.Items.Clear();
            if (ddlSource.Text == "Chennai")
            {

                ddlDestination.Items.Add("Madurai");
                ddlDestination.Items.Add("Trichy");
            }
            else if (ddlSource.Text == "Madurai")
            {
                ddlDestination.Items.Add("Chennai");
                ddlDestination.Items.Add("Trichy");

            }
            else if (ddlSource.Text == "Trichy")
            {
                ddlDestination.Items.Add("Chennai");
                ddlDestination.Items.Add("Madurai");
            }
            else
            {
                ddlDestination.Items.Insert(0, "Select");
            }



        }

        protected void ddlSource_SelectedIndexChanged(object sender, EventArgs e)
        {

            populateDestination();

        }

        private void populateSource()
        {
            ddlSource.Items.Clear();
            ddlSource.Items.Add("Chennai");
            ddlSource.Items.Add("Madurai");
            ddlSource.Items.Add("Trichy");
            ddlSource.Items.Insert(0, "Select");

        }
     
    }
}
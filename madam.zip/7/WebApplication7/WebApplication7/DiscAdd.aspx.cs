﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication7
{
    public partial class DiscAdd : System.Web.UI.Page
    {
        DataSet ds;
        SqlDataAdapter da;
        SqlConnection con;
        SqlCommandBuilder bldr;


        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                populateSource();
                ddlDestination.Items.Insert(0, "Select");
            }
          
          

        }

        private void populateSource()
        {
            ddlSource.Items.Clear();
            ddlSource.Items.Add("Chennai");
            ddlSource.Items.Add("Madurai");
            ddlSource.Items.Add("Trichy");
            ddlSource.Items.Insert(0, "Select");

        }

        private void populateDestination()
        {
            ddlDestination.Items.Clear();
            if (ddlSource.Text == "Chennai")
            {

                ddlDestination.Items.Add("Madurai");
                ddlDestination.Items.Add("Trichy");
            }
            else if (ddlSource.Text == "Madurai")
            {
                ddlDestination.Items.Add("Chennai");
                ddlDestination.Items.Add("Trichy");

            }
            else if (ddlSource.Text == "Trichy")
            {
                ddlDestination.Items.Add("Chennai");
                ddlDestination.Items.Add("Madurai");
            }
            else
            {
                ddlDestination.Items.Insert(0, "Select");
            }


        }

        protected void ddlSource_SelectedIndexChanged(object sender, EventArgs e)
        {

            populateDestination();

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            string conStr = System.Configuration.ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            con = new SqlConnection();
            con.ConnectionString = conStr;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_ViewBusDis";
            cmd.Connection = con;
            da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            ds = new DataSet();
            da.Fill(ds, "Bus");
            bldr = new SqlCommandBuilder(da);

            DataRow drnew = ds.Tables["Bus"].NewRow();
            drnew["busid"] = txtBusID.Text;
            drnew["source"] = ddlSource.Text;
            drnew["destination"] = ddlDestination.Text;
            drnew["price"] = int.Parse(txtPrice.Text);
            ds.Tables["Bus"].Rows.Add(drnew);
            da.Update(ds, "Bus");
          
          
        }

       
    }
}
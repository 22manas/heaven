﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;
using ABCBANKBLL;

namespace ABABANKBLLFACTORY
{
    public class CustomerBLLFactory
    {
        public static ICustomerBLL CreateCustomerBLL()
        {
            ICustomerBLL objcustbll = new CustomerBLL();
            return objcustbll;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;
using ABCBANKBO;

namespace ABCBANKBOFACTORY

{
    public class CustomerBOFactory
    {
        public static ICustomerBO CreateCustomerBO()
        {
            ICustomerBO objcustbo = new CustomerBO();
            return objcustbo;
        }

        public static ICustomerBO CreateCustomerBO(int customerID, string customerName, int branchID)
        {
            ICustomerBO objcustbo = new CustomerBO(customerID,customerName,branchID);
            return objcustbo;
        }

    }
}

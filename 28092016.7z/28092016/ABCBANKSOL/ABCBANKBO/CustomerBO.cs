﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;



namespace ABCBANKBO
{
    public class CustomerBO:ICustomerBO
    {

        int customerID;
        string customerName;
        int branchID;
        DateTime dob;
        bool isSeniorCustomer;


        public int CustomerID
        {
            get
            {
                return customerID;
            }

            set
            {

                customerID = value;

            }

        }


        public string CustomerName
        {
            get
            {
                return customerName;
            }

            set
            {

                customerName = value;

            }

        }

        public int BranchID
        {
            get
            {
                return branchID;
            }

            set
            {

                branchID = value;

            }
        }

        public DateTime DOB
        {
            get
            {
                return dob;
            }

            set
            {

                dob = value;

            }
        }

        public bool ISSeniorCustomer
        {
            get
            {
                return isSeniorCustomer;
            }

            set
            {

                isSeniorCustomer = value;

            }
        }


        public CustomerBO()
        {

        }

        public CustomerBO(int customerID,string customerName,int branchID)
        {
            this.customerID = customerID;
            this.customerName = customerName;
            this.branchID = branchID;

        }

        


    }
}

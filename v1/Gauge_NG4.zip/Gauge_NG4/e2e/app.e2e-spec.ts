import { GuagePage } from './app.po';

describe('guage App', () => {
  let page: GuagePage;

  beforeEach(() => {
    page = new GuagePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});

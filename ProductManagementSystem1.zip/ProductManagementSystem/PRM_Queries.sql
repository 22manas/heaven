Create Table tbl_PMS_Category_1184224
(
	CategoryId int primary key identity(1,1),
	CategoryName nvarchar(30) not null
)

Create Table tbl_PMS_ProductDetails_1184224
(
	ProductId int primary key identity(1,1),
	ProductName nvarchar(50) not null,
	CategoryId int foreign key references tbl_PMS_Category_1184224(CategoryId) not null,
	Stock int not null,
	[Description] nvarchar(200) not null
)

Select * from tbl_PMS_Category_1184224;
Select * from tbl_PMS_ProductDetails_1184224;

Insert into tbl_PMS_Category_1184224 Values ('Electronics');
Insert into tbl_PMS_Category_1184224 Values ('Furnitures');

Go
Create Proc usp_Add_tbl_PMS_ProductDetails_1184224
@ProductId int out,
@ProductName nvarchar(50),
@CategoryId int,
@Stock int,
@Description nvarchar(200)
As
Begin
	Insert Into tbl_PMS_ProductDetails_1184224  Values (@ProductName,@CategoryId,@Stock,@Description);
	Select @ProductId = ProductId from tbl_PMS_ProductDetails_1184224 where ProductName = @ProductName and CategoryId= @CategoryId and Stock = @Stock and [Description] = @Description;
End

Go
Create Proc usp_View_tbl_PMS_ProductDetails_1184224
@ProductId int
As
Begin
	Select ProductId,ProductName,CategoryName,Stock,Description from tbl_PMS_ProductDetails_1184224 as t1 inner join tbl_PMS_Category_1184224 as t2 on t1.CategoryId = t2.CategoryId where ProductId = @ProductId;
End

Go
Create Proc usp_Update_tbl_PMS_ProductDetails_1184224
@ProductId int,
@Stock int,
@Description nvarchar(200)
As
Begin
	Update tbl_PMS_ProductDetails_1184224 Set Stock = @Stock, [Description] = @Description where ProductId = @ProductId;
End

Go
Create Proc usp_GetProducts_tbl_PMS_ProductDetails_1184224
As
Begin
	Select ProductId, ProductName from tbl_PMS_ProductDetails_1184224;
End
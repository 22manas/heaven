﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ProductManagement_Types
{
    public interface IProduct_DAL
    {
        int Add(IProduct_BO objBO);
        DataSet View(int Id);
        int Update(IProduct_BO objBO);
        DataSet GetProducts();
    }
}

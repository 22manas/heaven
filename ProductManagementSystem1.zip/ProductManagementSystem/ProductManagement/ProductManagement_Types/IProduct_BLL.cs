﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ProductManagement_Types
{
    public interface IProduct_BLL
    {
        bool Add(IProduct_BO objBO);
        DataSet View(int Id);
        bool Update(IProduct_BO objBO);
        DataSet GetProducts();
    }
}

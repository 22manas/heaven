﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement_Types
{
    public interface IProduct_BO
    {
        int ProductId { get; set; }
        string ProductName { get; set; }
        int CategoryId { get; set; }
        int Stock { get; set; }
        string Description { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using ProductManagement_Types;
using ProductManagement_DAL;

namespace ProductManagement_BLL
{
    public class Product_BLL : IProduct_BLL
    {
        private IProduct_DAL objDAL;

        public Product_BLL()
        {
            objDAL = new Product_DAL();
        }

        public bool Add(IProduct_BO objBO)
        {
            if (objDAL.Add(objBO) == 1) return true;
            return false;
        }

        public bool Update(IProduct_BO objBO)
        {
            if (objDAL.Update(objBO) == 1) return true;
            return false;
        }

        public DataSet View(int Id)
        {
            return objDAL.View(Id);
        }

        public DataSet GetProducts()
        {
            return objDAL.GetProducts();
        }
    }
}

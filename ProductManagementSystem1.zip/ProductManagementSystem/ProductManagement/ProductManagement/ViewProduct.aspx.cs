﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProductManagement_Types;
using ProductManagement_BLL;
using ProductManagement_BO;

namespace ProductManagement
{
    public partial class ViewProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Data_Bind();
            }
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GridView1.Rows[GridView1.EditIndex];
            IProduct_BO objBO = new Product_BO();
            objBO.ProductId = Int32.Parse((row.FindControl("lblProductId") as Label).Text);
            objBO.Stock = Int32.Parse((row.FindControl("txtStock") as TextBox).Text);
            objBO.Description = (row.FindControl("txtDescription") as TextBox).Text;

            IProduct_BLL objBLL = new Product_BLL();
            if(objBLL.Update(objBO))
            {
                lblMsg.Text = "Succesfully Updated";
                lblMsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblMsg.Text = "There was a error while updating";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }

            GridView1.EditIndex = -1;
            Data_Bind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            Data_Bind();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            Data_Bind();
        }

        private void Data_Bind()
        {
            IProduct_BLL objBLL = new Product_BLL();
            GridView1.DataSource = objBLL.View((int)Session["ProductId"]);
            GridView1.DataBind();
        }
    }
}
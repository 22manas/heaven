﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProductManagement_Types;
using ProductManagement_BLL;

namespace ProductManagement
{
    public partial class View : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IProduct_BLL objBLL = new Product_BLL();
                ddlProduct.DataSource = objBLL.GetProducts();
                ddlProduct.DataTextField = "ProductName";
                ddlProduct.DataValueField = "ProductId";
                ddlProduct.DataBind();
                ListItem li = new ListItem("--Select--", "-1");
                ddlProduct.Items.Insert(0, li);
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                Session["ProductId"] = Int32.Parse(ddlProduct.SelectedValue);
                Response.Redirect("ViewProduct.aspx");
            }
        }
    }
}
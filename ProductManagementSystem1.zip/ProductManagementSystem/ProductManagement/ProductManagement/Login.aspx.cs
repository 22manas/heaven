﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace ProductManagement
{
    public partial class Login1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (FormsAuthentication.Authenticate(txtId.Text, txtPassword.Text))
            {
                Session["UserId"] = txtId.Text;
                FormsAuthentication.RedirectFromLoginPage(txtId.Text, false);
            }
            else
            {
                lblMsg.Text = "Invalid UserId or Password";
                lblMsg.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProductManagement_Types;
using ProductManagement_BO;
using ProductManagement_BLL;

namespace ProductManagement
{
    public partial class Add : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                IProduct_BO objBO = new Product_BO();
                objBO.ProductName = txtName.Text;
                objBO.CategoryId = Int32.Parse(ddlCategory.SelectedValue);
                objBO.Stock = Int32.Parse(txtStock.Text);
                objBO.Description = txtDescription.Text;

                IProduct_BLL objBLL = new Product_BLL();
                if (objBLL.Add(objBO))
                {
                    lblMsg.Text = "Succefully Added. Product Id is " + objBO.ProductId;
                    lblMsg.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblMsg.Text = "There Was a Error in Adding the Product";
                    lblMsg.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductManagement_Types;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ProductManagement_DAL
{
    public class Product_DAL : IProduct_DAL
    {
        private string connection;

        public Product_DAL()
        {
            connection = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        }

        public int Add(IProduct_BO objBO)
        {
            using(SqlConnection conn = new SqlConnection(connection))
            {
                int result;
                SqlCommand cmd = new SqlCommand("usp_Add_tbl_PMS_ProductDetails_1184224", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductName", objBO.ProductName);
                cmd.Parameters.AddWithValue("@CategoryId", objBO.CategoryId);
                cmd.Parameters.AddWithValue("@Stock", objBO.Stock);
                cmd.Parameters.AddWithValue("@Description", objBO.Description);
                SqlParameter param = new SqlParameter();
                param.Direction = ParameterDirection.Output;
                param.ParameterName = "@ProductId";
                param.SqlDbType = SqlDbType.Int;
                cmd.Parameters.Add(param);
                conn.Open();
                result = cmd.ExecuteNonQuery();
                objBO.ProductId = (int)param.Value;
                conn.Close();
                return result;
            }
        }

        public int Update(IProduct_BO objBO)
        {
            using (SqlConnection conn = new SqlConnection(connection))
            {
                int result;
                SqlCommand cmd = new SqlCommand("usp_Update_tbl_PMS_ProductDetails_1184224", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductId", objBO.ProductId);
                cmd.Parameters.AddWithValue("@Stock", objBO.Stock);
                cmd.Parameters.AddWithValue("@Description", objBO.Description);
                conn.Open();
                result = cmd.ExecuteNonQuery();
                conn.Close();
                return result;
            }
        }

        public DataSet View(int Id)
        {
            using(SqlConnection conn = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("usp_View_tbl_PMS_ProductDetails_1184224", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductId", Id);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
        }

        public DataSet GetProducts()
        {
            using (SqlConnection conn = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand("usp_GetProducts_tbl_PMS_ProductDetails_1184224", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication8
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            SqlConnection con;
            SqlCommand cmd;
            string constr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
            con = new SqlConnection();
            con.ConnectionString = constr;
            con.Open();
            cmd = new SqlCommand("insert_regtable", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userid",txtbxuserid.Text);
            cmd.Parameters.AddWithValue("@Password", txtbxpwd.Text);
            int res = cmd.ExecuteNonQuery();
            con.Close();
            if(res>0)
            {
                Response.Write("Inserted Successfully");
            }
        }
    }
}
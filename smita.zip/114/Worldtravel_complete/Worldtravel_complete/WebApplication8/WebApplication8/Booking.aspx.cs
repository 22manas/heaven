﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication8
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        SqlConnection conn;
        SqlCommand com;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                populateFromLocation();
                ddl_toloc.Items.Insert(0,"Select");

            }
        }

        protected void ddl_fromloc_SelectedIndexChanged(object sender, EventArgs e)
        {
            populateToLocation();
        }

        private void populateFromLocation()
        {
            ddl_fromloc.Items.Clear();
            ddl_fromloc.Items.Add("Chennai");
            ddl_fromloc.Items.Add("Bangalore");
            ddl_fromloc.Items.Add("Kanyakumari");
            ddl_fromloc.Items.Add("Hyderabad");
            ddl_fromloc.Items.Add("Madurai");
            ddl_fromloc.Items.Insert(0, "Select");
        }
        private void populateToLocation()
        {
            ddl_toloc.Items.Clear();
            if(ddl_fromloc.Text=="Chennai")
            {
                ddl_toloc.Items.Add("Bangalore");
                ddl_toloc.Items.Add("Kanyakumari");
                ddl_toloc.Items.Add("Hyderabad");
                ddl_toloc.Items.Add("Madurai");
            }
            else if(ddl_fromloc.Text=="Bangalore")
            {
                ddl_toloc.Items.Add("Chennai");
                ddl_toloc.Items.Add("Kanyakumari");
                ddl_toloc.Items.Add("Hyderabad");
                ddl_toloc.Items.Add("Madurai");
            }
            else if(ddl_fromloc.Text=="Kanyakumari")
            {
                ddl_toloc.Items.Add("Chennai");
                ddl_toloc.Items.Add("Bangalore");
                ddl_toloc.Items.Add("Hyderabad");
                ddl_toloc.Items.Add("Madurai");
            }
            else if (ddl_fromloc.Text == "Hyderabad")
            {
                ddl_toloc.Items.Add("Chennai");
                ddl_toloc.Items.Add("Bangalore");
                ddl_toloc.Items.Add("Kanyakumari");
                ddl_toloc.Items.Add("Madurai");
            }
            else if (ddl_fromloc.Text == "Madurai")
            {
                ddl_toloc.Items.Add("Chennai");
                ddl_toloc.Items.Add("Bangalore");
                ddl_toloc.Items.Add("Kanyakumari");
                ddl_toloc.Items.Add("Hyderabad");
            }
           
                ddl_toloc.Items.Insert(0, "Select");
        }

      

        protected void btn_bookingsubmit_Click(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
            conn = new SqlConnection(constr);
            conn.Open();
            com = new SqlCommand("insert_restables", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@fromloc", ddl_fromloc.Text);
            com.Parameters.AddWithValue("@toloc", ddl_toloc.Text);
            com.Parameters.AddWithValue("@nopassenger", int.Parse(txtbx_nopassenger.Text));
            com.Parameters.AddWithValue("@date", DateTime.Parse(txtdate.Text));
            com.Parameters.AddWithValue("@bustype", rbtn_bustype.Text);
            int res = com.ExecuteNonQuery();
            conn.Close();
            if(res>0)
            {
                Response.Write("Insertion Successful");
            }


        }

       

        protected void clndrdate_SelectionChanged(object sender, EventArgs e)
        {
           txtdate.Text = clndrdate.SelectedDate.ToString();
            
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WebApplication8
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        //string constr;
        SqlConnection conn;
        SqlCommand com;
        SqlDataAdapter da;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_view_Click(object sender, EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
            conn = new SqlConnection(constr);

           // com = new SqlCommand("validate2", conn);
            com = new SqlCommand("view_restables", conn);
            com.CommandType = CommandType.StoredProcedure;

            da = new SqlDataAdapter();
            da.SelectCommand = com;
            ds = new DataSet();
            da.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
}
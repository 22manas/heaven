create table Reg_table(Userid varchar(10) primary key,Password varchar(20))
insert into Reg_table values('sai','saismita')
create procedure insert_regtable
(@userid varchar(10),@Password varchar(20))
as 
begin
insert into Reg_table values(@userid,@Password)
end
create procedure validate1
(@userid varchar(10))
as
begin
select * from Reg_table where Userid=@userid
end
create procedure validate2
as
begin
select * from Reg_table 
end

create table Res_table(FromLocation varchar(20),ToLocation varchar(20),nopassenger int,Date date,Bustype varchar(10) )
create procedure insert_restable
(@fromloc varchar(20),@toloc varchar(20),@nopassenger int,@date date,@bustype varchar(10))
as 
begin
insert into Res_table values (@fromloc,@toloc,@nopassenger,@date,@bustype)
end
 create procedure view_restable
 as
 begin
 select * from Res_table
 end
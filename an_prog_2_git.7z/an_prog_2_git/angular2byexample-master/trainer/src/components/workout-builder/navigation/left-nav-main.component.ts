import { Component } from '@angular/core';

@Component({
    selector: 'left-nav-main',
    templateUrl: '/src/components/workout-builder/navigation/left-nav-main.component.html'
})
export class LeftNavMainComponent{
}
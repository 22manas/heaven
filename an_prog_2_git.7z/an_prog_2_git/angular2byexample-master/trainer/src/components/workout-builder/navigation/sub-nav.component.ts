import { Component } from '@angular/core';

@Component({
    selector: 'sub-nav',
    templateUrl: '/src/components/workout-builder/navigation/sub-nav.component.html'
})
export class SubNavComponent{
}